# Project Progress

> Update this document as work is completed. Do not mark an item complete without checking it in the current repository or recording evidence.

## Project
**Explainable Customer Churn Prediction Engine**

## Status Legend
- `[x]` Complete and verified
- `[ ]` Not yet verified or incomplete
- `[!]` Blocked or needs attention

## 1. Repository and Setup
- [ ] Root README reviewed against the actual implementation.
- [ ] `.gitignore` excludes virtual environments, `node_modules`, build outputs, and local secrets.
- [ ] Backend dependencies documented in `backend/requirements.txt`.
- [ ] Frontend dependencies and scripts documented in `frontend/package.json`.
- [ ] Clean-checkout setup tested.

## 2. Data and Model
- [ ] Dataset source and target column documented.
- [ ] Synthetic vs. real data clearly identified.
- [ ] Training and inference feature names/order verified.
- [ ] Model training script runs successfully.
- [ ] Saved model artifact can be loaded by the backend.
- [ ] Evaluation performed on a held-out dataset.
- [ ] Metrics, dataset split, and limitations recorded without unsupported claims.

## 3. Backend
- [ ] FastAPI starts locally.
- [ ] `GET /health` responds correctly.
- [ ] Health response accurately reports model readiness.
- [ ] Prediction endpoint validates input.
- [ ] Prediction endpoint returns the documented response schema.
- [ ] Error cases are handled and logged.
- [ ] CORS configuration includes only required origins.

## 4. Explainability and Recommendations
- [ ] SHAP explainer initializes with the deployed model.
- [ ] SHAP values are tested for representative inputs.
- [ ] LIME explainer initializes with the expected training data and feature names.
- [ ] Explanation labels and feature names are understandable.
- [ ] Risk-segment thresholds are documented.
- [ ] Retention recommendations are documented as suggestions, not guarantees.

## 5. Frontend
- [ ] Vite development server starts.
- [ ] Dashboard renders without browser-console errors.
- [ ] API base URL is configurable.
- [ ] Frontend can reach the local backend.
- [ ] Prediction results are displayed.
- [ ] SHAP/LIME explanations are displayed when returned.
- [ ] Loading, validation, and API error states are handled.

## 6. Testing
- [ ] Valid prediction request tested.
- [ ] Invalid/missing input tested.
- [ ] Backend unavailable case tested.
- [ ] Model unavailable case tested.
- [ ] CORS tested from the actual frontend origin.
- [ ] Production build tested.
- [ ] Public deployment tested, if deployed.

## 7. Deployment
- [ ] Backend hosting provider and URL documented.
- [ ] Frontend hosting provider and URL documented.
- [ ] Production API URL configured in frontend environment settings.
- [ ] Production CORS origin configured.
- [ ] Model/data artifacts available to the deployed service.
- [ ] Deployment logs checked.
- [ ] Final smoke test completed.

## 8. Evidence Log
Record dated evidence here. Replace the examples with actual results.

| Date | Area | Evidence / result | Follow-up |
|---|---|---|---|
| YYYY-MM-DD | Local backend | Add observed health response | Confirm model/explainer status |
| YYYY-MM-DD | Frontend | Add browser test result | Fix any console/API errors |
| YYYY-MM-DD | Deployment | Add deployed URL and smoke-test result | Resolve outstanding issues |

## 9. Current Blockers
- Add only blockers that currently exist in the project.
- Include the error message, file/endpoint affected, and next action.

## 10. Next Actions
1. Verify the model and dataset feature schema matches training and inference.
2. Confirm model and explainer readiness from the health endpoint.
3. Test a prediction end to end from the frontend.
4. Complete the checklist above and record actual evidence.
