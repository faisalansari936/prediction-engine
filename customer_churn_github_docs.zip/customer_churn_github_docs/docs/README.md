# Project Documentation

- [PLANNING.md](PLANNING.md): objectives, scope, architecture, and acceptance criteria.
- [PROGRESS.md](PROGRESS.md): checklists and evidence log to update as work is verified.
- [DEPLOYMENT.md](DEPLOYMENT.md): local preparation and typical frontend/backend deployment.
- [DEFENCE_QA.md](DEFENCE_QA.md): project defence questions and answer prompts.

These documents are tailored drafts based on the project details available in the conversation. If your institution or hackathon provided exact official templates, compare these documents with them or provide the templates so their headings and wording can be followed exactly.
