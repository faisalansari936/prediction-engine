# Deployment Guide

This guide describes a typical deployment for the React + FastAPI customer churn project. Hosting-provider interfaces and plan limits may change; verify current provider settings before deployment.

## 1. Deployment Overview
- **Repository:** GitHub
- **Frontend:** Vercel or another static frontend host
- **Backend:** Render or another Python-capable web-service host
- **API:** FastAPI served by Uvicorn
- **Model artifacts:** Must be available to the backend at runtime

Deploy the backend first, then configure and deploy the frontend with the backend's public URL.

## 2. Pre-deployment Checks
From the repository root:
- [ ] Confirm `backend/app/main.py` starts locally.
- [ ] Confirm `backend/requirements.txt` contains all runtime dependencies.
- [ ] Confirm the model artifact and required runtime data files are included or generated during deployment.
- [ ] Confirm model-loading paths are relative to the backend project, not a developer-specific absolute path.
- [ ] Confirm training and inference use the same features and preprocessing.
- [ ] Confirm `.gitignore` excludes `.env`, virtual environments, `node_modules`, and build output.
- [ ] Do not publish credentials, private customer data, or other sensitive information.
- [ ] Run a local prediction and check explanation output.

## 3. Publish to GitHub
From PowerShell in the project root:

```powershell
git status
git add .
git status
git commit -m "Prepare project for deployment"
git push
```

Inspect the staged-file list before committing. If the repository has no remote configured, add the GitHub repository URL first.

## 4. Deploy the FastAPI Backend

Create a web service from the GitHub repository in your chosen Python hosting provider.

Typical settings for a service whose root directory is `backend`:

- **Root directory:** `backend`
- **Build command:** `pip install -r requirements.txt`
- **Start command:** `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

Use the provider's required port variable and start-command format if it differs.

### Backend environment
- Set any required environment variables in the hosting dashboard.
- Do not put secrets in source code or commit them.
- Ensure `models/churn_model.json` and any required dataset or explainer background data are available at the paths expected by the application.
- Check dependency versions for Python, XGBoost, SHAP, and LIME compatibility.
- Review build and runtime logs after deployment.

### Backend smoke test
Open these paths using the actual service URL:
- `/health`
- `/docs`

The health response should accurately indicate whether the model and explainers loaded. A successful HTTP response alone does not prove prediction is working.

## 5. Configure and Deploy the Frontend

Set the frontend API base URL using a Vite environment variable, for example:

```text
VITE_API_URL=https://YOUR-BACKEND-HOST
```

Use the real backend URL, with no `/health` or `/predict` suffix when the application appends endpoint paths itself.

Typical frontend host settings:
- **Root directory:** `frontend`
- **Build command:** `npm run build`
- **Output directory:** `dist`
- **Environment variable:** `VITE_API_URL` set to the deployed backend base URL

After changing a Vite environment variable, rebuild/redeploy the frontend. Vite variables prefixed with `VITE_` are exposed to browser code; never store secrets in them.

## 6. Configure CORS

In FastAPI, allow the exact production frontend origin, for example:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:5174",
        "https://YOUR-FRONTEND-HOST",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

Replace the example production origin with the real deployed domain. Keep only origins that are needed. If your application does not use cookies or credentialed requests, review whether `allow_credentials=True` is necessary.

## 7. Production Smoke Test
- [ ] Frontend URL loads over HTTPS.
- [ ] Backend health endpoint responds.
- [ ] Health payload reports model readiness correctly.
- [ ] Browser network panel shows requests going to the deployed backend, not `localhost`.
- [ ] CORS preflight and API requests succeed.
- [ ] A valid prediction request succeeds.
- [ ] Invalid input returns a controlled error.
- [ ] SHAP and LIME explanations work for a representative input.
- [ ] Browser console and host logs contain no unresolved errors.

## 8. Common Problems

| Symptom | Checks |
|---|---|
| Connection refused | Backend service state, public URL, port binding, logs |
| CORS error | Exact frontend origin and middleware configuration |
| 404 | API path and whether a prefix is used |
| 422 | Request JSON matches the Pydantic schema |
| 500 | Backend logs, model loading, feature schema, explainer exceptions |
| Model not loaded | Artifact included, correct relative paths, dependency compatibility |
| Works locally but not in hosting | Environment variables, filesystem assumptions, Python version, case-sensitive paths |
| Frontend still calls localhost | Production `VITE_API_URL`, rebuild and redeploy |

## 9. Rollback and Operations
- Keep known-good commits and deployment logs.
- Revert to a known-good commit if a release breaks the application.
- Avoid storing customer records or secrets in logs.
- Re-test the health and prediction endpoints after dependency or model changes.

## 10. Deployment Record
Fill this in after deployment is complete.

- **Backend provider:** TODO
- **Backend URL:** TODO
- **Frontend provider:** TODO
- **Frontend URL:** TODO
- **Deployment date:** TODO
- **Smoke test result:** TODO
- **Known limitations:** TODO
