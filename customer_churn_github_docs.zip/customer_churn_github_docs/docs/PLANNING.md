# Project Planning

## Project
**Explainable Customer Churn Prediction Engine**

## 1. Problem Statement
Customer churn can reduce recurring revenue and increase the cost of acquiring replacement customers. This project aims to build a prototype that estimates churn risk from customer attributes and presents explanations and possible retention actions to support human review.

## 2. Objectives
- Build a machine-learning workflow for customer churn prediction.
- Expose prediction functionality through a Python FastAPI REST API.
- Provide a React and TypeScript interface for entering customer details and reviewing results.
- Use SHAP and LIME to explain individual predictions where supported by the trained model and installed library versions.
- Group predictions into configurable risk segments.
- Present retention suggestions as decision-support guidance, not guaranteed outcomes.
- Document local setup, testing, limitations, and deployment.

## 3. Scope

### In scope
- Data loading and model training/inference.
- Prediction API and health endpoint.
- Frontend-to-backend integration.
- SHAP/LIME explanation display.
- Configurable risk thresholds and retention recommendations.
- Reproducible local setup and deployment instructions.

### Out of scope for the current prototype
- Production customer-data integration.
- Automated contact with customers.
- Guarantees that a prediction or recommendation will prevent churn.
- Claims of production-grade accuracy without documented evaluation on held-out, representative data.
- Authentication, authorization, and enterprise monitoring unless implemented separately.

## 4. Proposed Technology
| Layer | Technology | Purpose |
|---|---|---|
| Frontend | React, TypeScript, Vite | Dashboard and customer input |
| Backend | Python, FastAPI, Uvicorn | REST API |
| Model | XGBoost, scikit-learn | Churn prediction |
| Explainability | SHAP, LIME | Local prediction explanations |
| Data handling | pandas, NumPy | Dataset preparation |
| Version control | Git, GitHub | Source history and collaboration |

Confirm actual dependencies against `backend/requirements.txt` and `frontend/package.json`.

## 5. Proposed Architecture
1. The user enters customer attributes in the React interface.
2. The frontend sends a JSON request to the FastAPI prediction endpoint.
3. The backend validates the input and applies the same feature preparation used during training.
4. The model returns a churn probability or class.
5. The backend creates SHAP/LIME explanations when available.
6. The application maps the result to a configured risk segment and suggests relevant retention actions.
7. The frontend displays the result and its explanation.

## 6. Work Plan
- [ ] Inspect and document the dataset and target label.
- [ ] Verify the training script and saved model artifact use the same feature schema.
- [ ] Train the model and record evaluation results on an appropriate held-out dataset.
- [ ] Implement and test the FastAPI health and prediction endpoints.
- [ ] Implement SHAP and LIME explanation handling.
- [ ] Connect the React frontend to the API.
- [ ] Test success and failure cases, including invalid input and model-loading failure.
- [ ] Add privacy-safe documentation and repository hygiene files.
- [ ] Deploy backend and frontend, then test the public URLs.
- [ ] Capture final screenshots and update `docs/PROGRESS.md`.

## 7. Acceptance Criteria
- The documented local setup works from a clean checkout.
- `/health` reports service and model readiness accurately.
- The prediction endpoint validates requests and returns a documented response schema.
- Frontend requests use a configurable API base URL.
- CORS allows only the required frontend origins.
- Explanation output is clearly labelled and does not misrepresent model attribution as causation.
- Risk thresholds and retention suggestions are documented.
- Tests and measured metrics are reported honestly.
- No secrets or private customer data are committed.

## 8. Risks and Mitigations
| Risk | Mitigation |
|---|---|
| Training and inference features differ | Define and validate one shared feature schema |
| Model artifact missing in deployment | Confirm artifact is committed or supplied during build |
| SHAP/LIME version incompatibility | Pin compatible dependencies and test deployed versions |
| CORS or incorrect API URL | Configure the deployed frontend origin and environment variable |
| Synthetic data gives misleading results | Label synthetic data and avoid real-world performance claims |
| Sensitive data is accidentally published | Use `.gitignore`, inspect staged files, and use synthetic/demo data |

## 9. Ethical and Responsible Use
Predictions may be wrong and can reflect bias in training data. Treat results as decision support, assess performance across relevant groups when appropriate, minimize data collection, and do not make consequential customer decisions solely from the model output.

## 10. Planning Status
This document describes the intended plan. Track completed work and evidence in [`PROGRESS.md`](PROGRESS.md).
