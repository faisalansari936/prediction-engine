# Project Defence: Questions and Answers

Use these as preparation notes. Adapt answers to the implementation and test results that actually exist in your repository. Do not claim metrics, deployment success, or completed features unless you can demonstrate them.

## 1. Project Overview

### Q1. What is the project?
It is a customer churn prediction prototype. It estimates the likelihood that a customer may leave and aims to show explanations and possible retention actions through a web interface.

### Q2. What problem does it address?
Customer churn can affect recurring revenue and increase customer acquisition costs. Predictive signals can help an organization decide which customers may need further review or support.

### Q3. Who could use it?
A customer-success, retention, or analytics team could use it as a decision-support tool, provided the model has been validated on suitable data and the organization has appropriate privacy and governance controls.

### Q4. What are the main modules?
The project has a React frontend, a FastAPI backend, a trained prediction model, SHAP/LIME explanation logic, and risk-segmentation/retention-recommendation logic where implemented.

## 2. Technology Choices

### Q5. Why use React?
React supports reusable interface components and interactive updates for customer inputs, prediction results, and explanation displays.

### Q6. Why use FastAPI?
FastAPI provides a Python-based REST API, request validation, and interactive API documentation. It can connect the frontend to Python machine-learning libraries.

### Q7. Why use XGBoost?
XGBoost is a gradient-boosted decision-tree library that can model nonlinear relationships and feature interactions in tabular data. Its suitability should be demonstrated through evaluation against a relevant baseline.

### Q8. What is SHAP?
SHAP is a feature-attribution approach based on Shapley values. It estimates how features contribute to a model output under a particular explainer and output definition. It does not prove causation.

### Q9. What is LIME?
LIME explains an individual prediction by fitting a simpler interpretable model around the input being explained. Its result can depend on the sampling and configuration.

### Q10. Why use both SHAP and LIME?
They offer different explanation approaches and can provide complementary views. Their outputs may differ because their assumptions and methods differ; they should not be expected to produce identical explanations.

## 3. Machine Learning

### Q11. What is the target variable?
The target is the dataset's churn label. State the exact column name and label encoding from the dataset used by this project.

### Q12. Which features are used?
List the exact input features from the training script and model. Explain how categorical fields are encoded and how missing or invalid values are handled.

### Q13. How is the model evaluated?
Describe the actual train/validation/test split and metrics recorded by the project. Common classification metrics include precision, recall, F1-score, ROC-AUC, and a confusion matrix. Do not state values unless they have been measured.

### Q14. Why is accuracy alone not enough?
If churn cases are relatively rare, a model can achieve high accuracy by predicting the majority class. Precision, recall, F1-score, ROC-AUC, calibration, and the costs of different errors can provide a fuller assessment.

### Q15. What is overfitting?
Overfitting occurs when a model learns patterns specific to training data that do not generalize well to unseen data. A held-out evaluation set and careful validation help assess this risk.

### Q16. What does a churn probability mean?
It is the model's estimated probability under its training and calibration assumptions. It is not a certainty that the customer will leave and may need calibration before operational use.

### Q17. What are the risk categories?
Explain the actual thresholds configured in the code. If thresholds are not yet validated, say they are provisional and should be selected based on business costs and validation results.

## 4. Explainability

### Q18. Does SHAP tell us why a customer will churn?
It describes how input features contribute to the model's output for that prediction. It does not establish real-world causation or prove that changing a feature will change customer behavior.

### Q19. Why might SHAP and LIME explanations differ?
They use different assumptions and procedures. Differences can also arise from feature scaling, sampling, explainer configuration, output choice, and library versions.

### Q20. What if an explainer fails?
The API should log the technical error and return a controlled response. The application must not silently present placeholder explanations as genuine SHAP or LIME results.

## 5. API and Web Application

### Q21. How does the frontend communicate with the backend?
The React frontend sends HTTP requests with customer data encoded as JSON. FastAPI validates the request, runs inference, and returns a JSON response for the interface to display.

### Q22. What is CORS?
Cross-Origin Resource Sharing is a browser security mechanism controlling which origins may read responses from an API. The backend should allow the specific local and deployed frontend origins that are needed.

### Q23. What does HTTP 200 mean?
It indicates that the request was handled successfully at the HTTP level. It does not, by itself, prove that the model loaded correctly or that the prediction and explanation values are valid.

### Q24. What does HTTP 422 usually mean in FastAPI?
It commonly indicates request validation failed, for example because a required field is missing or a field has the wrong type.

### Q25. How are model artifacts loaded?
Explain the actual model file, path construction, and startup-loading behavior used in `backend/app/main.py`. Confirm that the artifact is available in the deployment environment.

## 6. Data, Limitations, and Ethics

### Q26. Is the data real or synthetic?
State the actual source. If it is synthetic, explain that it is suitable for demonstrating a workflow but cannot establish real-world business performance.

### Q27. What are the main limitations?
Potential limitations include data representativeness, class imbalance, drift, uncalibrated probabilities, feature/label leakage, model bias, and explanation instability. Identify which have been tested and which remain open.

### Q28. Could the model be biased?
Yes. Historical data can encode differences in service access or business practices. Evaluation should consider data quality, performance across relevant groups where lawful and appropriate, and human review.

### Q29. Should a company automatically act on these predictions?
Not solely on the model output. Predictions and explanations should be reviewed alongside customer context, privacy requirements, business policy, and measured outcomes.

### Q30. How do you protect data?
Avoid committing sensitive customer data, secrets, or credentials. Use access controls, minimize retained data, and follow applicable organizational and legal requirements for any real deployment.

## 7. Deployment and Future Work

### Q31. How would you deploy the project?
A typical setup hosts the React frontend on a static web host and the FastAPI backend on a Python-capable web service. The frontend API URL and backend CORS allowlist must be configured for the deployed domains.

### Q32. What deployment issues might occur?
Common issues include incorrect API URLs, CORS restrictions, missing model artifacts, dependency incompatibilities, filesystem assumptions, and environment-variable configuration.

### Q33. What would you improve next?
Possible improvements include evaluation on representative data, probability calibration, threshold selection based on business costs, model monitoring, drift detection, secure authentication, and testing retention actions against measured outcomes.

## 8. Demonstration Checklist

Before the defence, verify these items in the actual project:

- [ ] Start the backend and show the health endpoint.
- [ ] Show the `/docs` API documentation.
- [ ] Start the frontend and open the dashboard.
- [ ] Submit one valid example customer.
- [ ] Explain the predicted output and risk segment.
- [ ] Show SHAP/LIME output only if it is generated by the actual explainers.
- [ ] Demonstrate how invalid input or backend failure is handled.
- [ ] Show the repository structure and setup instructions.
- [ ] Explain the dataset source and measured evaluation results.
- [ ] State known limitations honestly.

## 9. Project-specific facts to fill in

- **Dataset and source:** TODO
- **Target column and label encoding:** TODO
- **Feature list:** TODO
- **Train/test split:** TODO
- **Measured evaluation metrics:** TODO
- **Risk thresholds:** TODO
- **Backend deployment URL:** TODO
- **Frontend deployment URL:** TODO
- **Known limitations:** TODO
